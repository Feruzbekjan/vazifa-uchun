abstract class AppImages{
  static const profile = "assets/images/login/profile.png";
}